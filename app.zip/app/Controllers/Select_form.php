<?php

namespace App\Controllers;

use App\Models\MstStatusModel;
use App\Models\MstJobModel;
use App\Models\MstEmpTypeModel;
use App\Models\MstDeptModel;
use App\Models\OpeningModel;
use App\Models\CandidateModel;

class Select_form extends BaseController
{
    protected $MstStatusModel;
    protected $MstJobModel;
    protected $MstEmpTypeModel;
    protected $MstDeptModel;
    protected $OpeningModel;
    protected $CandidateModel;

    public function __construct()
    {
        $this->MstStatusModel = new MstStatusModel();
        $this->MstJobModel = new MstJobModel();
        $this->MstEmpTypeModel = new MstEmpTypeModel();
        $this->MstDeptModel = new MstDeptModel();
        $this->OpeningModel = new OpeningModel();
        $this->CandidateModel = new CandidateModel();
    }

    public function statusSelect()
    {
        $q = $this->request->getGet('q');

        $builder = $this->MstStatusModel->builder();
        $builder->select('DISTINCT(status) as status');

        if (!empty($q)) {
            $builder->like('status', $q);
        }

        $query = $builder->get();
        $results = $query->getResult();

        $items = [];
        foreach ($results as $row) {
            $items[] = [
                'id' => $row->status,
                'name' => $row->status
            ];
        }

        return $this->response->setJSON(['items' => $items]);
    }

    public function jobTitleSelect()
    {
        $q = $this->request->getGet('q');

        $builder = $this->MstJobModel->builder();
        $builder->select('DISTINCT(job_title) as job_title');

        if (!empty($q)) {
            $builder->like('job_title', $q);
        }

        $query = $builder->get();
        $results = $query->getResult();

        $items = [];
        foreach ($results as $row) {
            $items[] = [
                'id' => $row->job_title,
                'name' => $row->job_title
            ];
        }

        return $this->response->setJSON(['items' => $items]);
    }

    public function empTypeSelect()
    {
        $q = $this->request->getGet('q');

        $builder = $this->MstEmpTypeModel->builder();
        $builder->select('DISTINCT(type) as type');

        if (!empty($q)) {
            $builder->like('type', $q);
        }

        $query = $builder->get();
        $results = $query->getResult();

        $items = [];
        foreach ($results as $row) {
            $items[] = [
                'id' => $row->type,
                'name' => $row->type
            ];
        }

        return $this->response->setJSON(['items' => $items]);
    }

    public function deptSelect()
    {
        $q = $this->request->getGet('q');

        $builder = $this->MstDeptModel->builder();
        $builder->select('DISTINCT(department) as department');

        if (!empty($q)) {
            $builder->like('department', $q);
        }

        $query = $builder->get();
        $results = $query->getResult();

        $items = [];
        foreach ($results as $row) {
            $items[] = [
                'id' => $row->department,
                'name' => $row->department
            ];
        }

        return $this->response->setJSON(['items' => $items]);
    }

    public function jobOpeningSelect()
    {
        $q = $this->request->getGet('q');

        $builder = $this->OpeningModel->builder();
        $builder->distinct();
        $builder->select('job_id, position');

        if (!empty($q)) {
            $builder->groupStart()
                ->like('job_id', $q)
                ->orLike('position', $q)
                ->groupEnd();
        }

        $query = $builder->get();
        $results = $query->getResult();

        $items = [];
        foreach ($results as $row) {
            $items[] = [
                'id' => $row->job_id,
                'name' => $row->job_id . ' - ' . $row->position
            ];
        }

        return $this->response->setJSON(['items' => $items]);
    }

    public function candidateSelect()
    {
        $q = $this->request->getGet('q');

        $builder = $this->CandidateModel->builder();
        $builder->distinct();
        $builder->select('id, candidate_name');

        if (!empty($q)) {
            $builder->like('candidate_name', $q);
        }

        $query = $builder->get();
        $results = $query->getResult();

        $items = [];
        foreach ($results as $row) {
            $items[] = [
                'id' => $row->id,
                'name' => $row->candidate_name
            ];
        }

        return $this->response->setJSON(['items' => $items]);
    }
}
