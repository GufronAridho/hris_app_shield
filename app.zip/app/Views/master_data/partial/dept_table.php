<?php foreach ($item as $i): ?>
    <tr>
        <td class="text-center">
            <span class="badge bg-secondary" style="font-size: 1rem;">
                <?= $i['dept_code']; ?>
            </span>
        </td>
        <td class=""><?= $i['department']; ?> </td>
        <td class=""><?= $i['dept_head']; ?> </td>
        <td class="text-center">
            <button class="btn btn-sm btn-info edit-btn me-1"
                data-id="<?= $i['id']; ?>" data-dept_code="<?= $i['dept_code']; ?>"
                data-department="<?= $i['department']; ?>" data-dept_head="<?= $i['dept_head']; ?>">
                <i class="fa fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-danger delete-btn"
                data-id="<?= $i['id']; ?>">
                <i class="fa fa-trash"></i>
            </button>
        </td>
    </tr>
<?php endforeach ?>